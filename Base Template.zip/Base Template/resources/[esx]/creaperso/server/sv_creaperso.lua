ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent("GB:EventSetInfoToSql")
AddEventHandler("GB:EventSetInfoToSql", function(nameInput,prenomInput,DateInput,tailleInput,sexInput)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	MySQL.Async.execute("UPDATE users SET nom = @nom, prenom = @prenom, datenaissance = @datenaissance, taille = @taille, sexe = @sexe WHERE identifier = @identifier",{
      ['@identifier'] = xPlayer.identifier,
	  ['@nom'] = nameInput,
	  ['@prenom'] = prenomInput,
	  ['@datenaissance'] = DateInput,
	  ['@taille'] = tailleInput,
	  ['@sexe'] = sexInput
    })
end)