ESX                  = nil
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
    ESX.PlayerData = ESX.GetPlayerData()
end)

local FirstSpawn = true
local PlayerLoaded = false
AddEventHandler('playerSpawned', function()
	CreateThread(function()
		while not PlayerLoaded do
			Wait(10)
		end
		if FirstSpawn then
			ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
				if skin == nil then
                    TriggerEvent('skinchanger:loadSkin', {sex = 0})
                    TriggerEvent("GB:EventSpawnPLayer")
				else
                    TriggerEvent('skinchanger:loadSkin', skin)
				end
			end)
			FirstSpawn = false
		end
	end)
end)
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    ESX.PlayerData = xPlayer
	PlayerLoaded = true
end)

function createcam(default)
    DisplayRadar(false)
    RenderScriptCams(false, false, 0, 1, 0)
    DestroyCam(cam, false)
    if (not DoesCamExist(cam)) then
        SetCamActive(cam, true)
        RenderScriptCams(true, false, 0, true, false)
    end
end

function destorycam()
    RenderScriptCams(false, false, 0, 1, 0)
    DestroyCam(cam, false)
    FreezeEntityPosition(PlayerPedId(), false)
end

function CreateCamEnter()
    cam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", -1307.8790, -1554.7883, 5.3114, 0.00, 0.00, 200.0, 20.00, false, 0)
    SetCamActive(cam, true)
    RenderScriptCams(true, false, 2000, true, true) 
end

RegisterNetEvent('GB:EventSpawnPLayer')
AddEventHandler('GB:EventSpawnPLayer', function()
    DisplayRadar(false)
    CreateCamEnter()
    SetEntityCoords(PlayerPedId(), -1307.1105, -1556.7149, 4.6411 -0.98, 0.0, 0.0, 0.0, 10)
    SetEntityHeading(PlayerPedId(), 22.40755)
    Wait(1000)
    CreaidentityMenu()
    FreezeEntityPosition(PlayerPedId(), true)
end)

function KeyboardInput(entryTitle, textEntry, inputText, maxLength)
    AddTextEntry(entryTitle, textEntry)
    DisplayOnscreenKeyboard(1, entryTitle, '', inputText, '', '', '', maxLength)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do
        Wait(0)
    end
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        return result
    else
        return nil
    end
end