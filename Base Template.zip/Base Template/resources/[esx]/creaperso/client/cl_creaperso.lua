local actionGender, actionMother, actionFather, actionRessemblance, actionSkin = 1, 1, 1, 5, 5
local CharacterMom, CharacterDad, ShapeMixData, SkinMixData = 1, 1, 0.5, 0.5
local prenomInput, nameInput, tailleInput,sexInput,DateInput = nil, nil, nil, nil,nil
local passe = false

local MotherListCreator = { "Hannah", "Aubrey", "Jasmine", "Gisele", "Amelia", "Isabella", "Zoe", "Ava", "Camila", "Violet", "Sophia", "Evelyn", "Nicole", "Ashley", "Gracie", "Brianna", "Natalie", "Olivia", "Elizabeth", "Charlotte", "Emma" }
local FatherListCreator = { "Benjamin", "Daniel", "Joshua", "Noah", "Andrew", "Juan", "Alex", "Isaac", "Evan", "Ethan", "Vincent", "Angel", "Diego", "Adrian", "Gabriel", "Michael", "Santiago", "Kevin", "Louis", "Samuel", "Anthony",  "Claude", "Niko" }


local creaperso = RageUI.CreateMenu("Création", "Personnage")
local heritage = RageUI.CreateSubMenu(creaperso, "Héritage", "HÉritage")
local visage = RageUI.CreateSubMenu(creaperso, "Visage", "DÉtail du visage")
local apperance = RageUI.CreateSubMenu(creaperso, "Apparence", "DÉtails de l'apparence")
local identity2 = RageUI.CreateSubMenu(creaperso, "Identité", "CrÉation d'identitÉ")
local clothes = RageUI.CreateSubMenu(creaperso, "Vêtements", "Choix des vêtements")
visage.EnableMouse = true;
apperance.EnableMouse = true;
creaperso.Closable = false


function CreaidentityMenu()
    changeGender(1)
    GenerateClotheList()
    if opencrea then
        return
    else
        opencrea = true 
        RageUI.Visible(creaperso, true)
        CreateThread(function()
            while opencrea do
                    RageUI.IsVisible(creaperso,function()
                        RageUI.List('Choisir son Sexe', {"Homme", "Femme"}, actionGender, description, {}, true, {
                            onListChange = function(Index, Item)
                                actionGender = Index
                            end,
                            onSelected = function(Index, Item)
                                actionGender = Index
                                changeGender(Index)
                            end,
                        })
                        RageUI.Button("Héritage", nil, {}, true , {
                            onSelected = function()
                                heritage.Controls.Back.Enabled = true
                            end
                        },heritage)
                        RageUI.Button("Traits du visage", nil, {}, true , {
                            onSelected = function()
                                visage.Controls.Back.Enabled = true
                            end
                        },visage)
                        RageUI.Button("Apparence", nil, {}, true , {
                            onSelected = function()
                                apperance.Controls.Back.Enabled = true
                            end
                        },apperance)
                        RageUI.Button("Identité", nil, {}, true , {
                            onSelected = function()
                                updateClothe(1)
                            end
                        },identity2)
                    end)
                    RageUI.IsVisible(heritage,function()
                        RageUI.Window.Heritage(CharacterMom, CharacterDad)
                        RageUI.List('Mère', MotherListCreator, actionMother, description, {}, true, {
                            onListChange = function(Index, Item)
                                actionMother = Index
                                CharacterMom = Index
                                Character['mom'] = Index
                                SetPedHeadBlendData(PlayerPedId(), CharacterMom, CharacterDad, nil, CharacterMom, CharacterDad, nil, ShapeMixData, SkinMixData, nil, true)
                            end,
                            onSelected = function(Index, Item)
                            end,
                        })
                        RageUI.List('Père', FatherListCreator, actionFather, description, {}, true, {
                            onListChange = function(Index, Item)
                                actionFather = Index
                                CharacterDad = Index
                                Character['dad'] = Index
                                SetPedHeadBlendData(PlayerPedId(), CharacterMom, CharacterDad, nil, CharacterMom, CharacterDad, nil, ShapeMixData, SkinMixData, nil, true)
                            end,
                            onSelected = function(Index, Item)
                            end,
                        })
                        RageUI.UISliderHeritage('Ressemblance', actionRessemblance, description, {
                            onSliderChange = function(Float, Index)
                                actionRessemblance = Index
                                ShapeMixData = Index/10
                                Character['face'] = Index/10
                                SetPedHeadBlendData(PlayerPedId(), CharacterMom, CharacterDad, nil, CharacterMom, CharacterDad, nil, ShapeMixData, SkinMixData, nil, true)
                            end,
                            onSelected = function(Float, Index)
                            end
                        })
                        RageUI.UISliderHeritage('Teint de peau', actionSkin, description, {
                            onSliderChange = function(Float, Index)
                                actionSkin = Index
                                SkinMixData = Index/10
                                Character['skin'] = Index/10
                                SetPedHeadBlendData(PlayerPedId(), CharacterMom, CharacterDad, nil, CharacterMom, CharacterDad, nil, ShapeMixData, SkinMixData, nil, true)
                            end,
                            onSelected = function(Float, Index)
                            end
                        })
                    end)
                    RageUI.IsVisible(visage,function()
                        RageUI.Button("Nez", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {0, 'nose_1'}, y = {1, 'nose_2'}, Top = "Haut", Bottom = "Bas", Left = "Étroit", Right = "Large"})
                            end
                        })
                        RageUI.Button("Profil nez", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {2, 'nose_3'}, y = {3, 'nose_4'}, Top = "Courber", Bottom = "Incurver", Left = "Court", Right = "Long"})
                            end
                        })
                        RageUI.Button("Pointe de nez", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {4, 'nose_5'}, y = {5, 'nose_6'}, Top = "Casser à gauche", Bottom = "Casser à droite", Left = "Pointe Haute", Right = "Pointe Basse"})
                            end
                        })
                        RageUI.Button("Sourcils", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {6, 'eyebrows_5'}, y = {7, 'eyebrows_6'}, Top = "Haut", Bottom = "Bas", Left = "Extérieur", Right = "Intérieur"})
                            end
                        })
                        RageUI.Button("Pommettes", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {9, 'cheeks_1'}, y = {8, 'cheeks_2'}, Top = "Haut", Bottom = "Bas", Left = "Creuse", Right = "Gonfler"})
                            end
                        })
                        RageUI.Button("Joues", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {10, 'cheeks_3'}, Left = "Gonfler", Right = "Creuse"})
                            end
                        })
                        RageUI.Button("Yeux", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {11, 'eye_open'}, Left = "Ouvert", Right = "Plisser"})
                            end
                        })
                        RageUI.Button("Lèvres", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {12, 'lips_thick'}, Left = "Épais", Right = "Mince"})
                            end
                        })
                        RageUI.Button("Mâchoire", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {13, 'jaw_1'}, y = {14, 'jaw_2'}, Top = "Rond", Bottom = "Carré", Left = "Étroit", Right = "Large"})
                            end
                        })
                        RageUI.Button("Menton", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {15, 'chin_height'}, y = {16, 'chin_lenght'}, Top = "Haut", Bottom = "Bas", Left = "Profond", Right = "Extérieur"})
                            end
                        })
                        RageUI.Button("Forme de menton", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {17, 'chin_width'}, y = {18, 'chin_hole'}, Top = "Pointu", Bottom = "Bum", Left = "Rond", Right = "Carré"})
                            end
                        })
                        RageUI.Button("Épaisseur du cou", nil, {}, true , {
                            onActive = function()
                                ManagePanel('GridPanel', {x = {19, 'neck_thick'}, Left = "Mince", Right = "Épais"})
                            end
                        })
                        if Panel.GridPanel.enable then
                            RageUI.GridPanel(Panel.GridPanel.x, Panel.GridPanel.y, Panel.GridPanel.Top, Panel.GridPanel.Bottom, Panel.GridPanel.Left, Panel.GridPanel.Right, function(Hovered, Active, X, Y)
                                if Panel.GridPanel.lastItem == Panel.GridPanel.currentItem then
                                    Panel.GridPanel.x = X
                                    Panel.GridPanel.y = Y
                                else
                                    Panel.GridPanel.x = Panel.GridPanel[Panel.GridPanel.currentItem].x
                                    Panel.GridPanel.y = Panel.GridPanel[Panel.GridPanel.currentItem].y
                                end
        
        
                                if Active then
                                    Panel.GridPanel[Panel.GridPanel.currentItem].x = X
                                    Panel.GridPanel[Panel.GridPanel.currentItem].y = Y
        
                                    SetPedFaceFeature(PlayerPedId(), Panel.GridPanel.PFF[1], X)
                                    SetPedFaceFeature(PlayerPedId(), Panel.GridPanel.PFF2[1], Y)
        
                                    Character[Panel.GridPanel.PFF[2]] = X
                                    Character[Panel.GridPanel.PFF2[2]] = Y
                                end
                            end)
                        end
        
                        if Panel.GridPanelHorizontal.enable then
                            RageUI.GridPanelHorizontal(Panel.GridPanelHorizontal.x, Panel.GridPanelHorizontal.Left, Panel.GridPanelHorizontal.Right, function(Hovered, Active, X)
                                if Panel.GridPanelHorizontal.lastItem == Panel.GridPanelHorizontal.currentItem then
                                    Panel.GridPanelHorizontal.x = X
                                else
                                    Panel.GridPanelHorizontal.x = Panel.GridPanelHorizontal[Panel.GridPanelHorizontal.currentItem].x
                                end
                                if Active then
                                    Panel.GridPanelHorizontal[Panel.GridPanelHorizontal.currentItem].x = X
                                    SetPedFaceFeature(PlayerPedId(), Panel.GridPanelHorizontal.PFF[1], X)
                                    Character[Panel.GridPanelHorizontal.PFF[2]] = X
                                end
                            end)
                        end
                    end)
                    RageUI.IsVisible(apperance,function()
                        for k,v in ipairs(Apperance) do
                            RageUI.List(v.itemmenu, v.List, v.index, v.itemmenu, {}, true, {
                                onListChange = function(Index, Item)
                                    v.index = Index
                                    if v.ColourPanel and v.PercentagePanel then
                                        ManagePanel('ColourPanel', {Panel = 'PercentagePanel', index = k, item = v.item})
                                    elseif v.ColourPanel and not v.PercentagePanel then
                                        ManagePanel('ColourPanel', {index = k, item = v.item})
                                    elseif not v.ColourPanel and v.PercentagePanel then
                                        ManagePanel('PercentagePanel', {index = k, item = v.item})
                                    elseif not v.ColourPanel and not v.PercentagePanel then
                                        ManagePanel('', {})
                                    end
                                    updateApperance(k)
                                end,
                                onSelected = function(Index, Item)
                                    v.index = Index
                                end,
                            })
                        end
                        if Panel.ColourPanel.enable then
                            RageUI.ColourPanel(Panel.ColourPanel.name, Panel.ColourPanel.Color, Panel.ColourPanel.index_one, Panel.ColourPanel.index_two, function(Hovered, Active, MinimumIndex, CurrentIndex)
                                if Panel.ColourPanel.lastItem == Panel.ColourPanel.currentItem then
                                    Panel.ColourPanel.index_one = MinimumIndex
                                    Panel.ColourPanel.index_two = CurrentIndex
                                else
                                    Panel.ColourPanel.index_one = Panel.ColourPanel[Panel.ColourPanel.currentItem].minindex
                                    Panel.ColourPanel.index_two = Panel.ColourPanel[Panel.ColourPanel.currentItem].index
                                end
        
                                if Active then
                                    Panel.ColourPanel[Panel.ColourPanel.currentItem].minindex = MinimumIndex
                                    Panel.ColourPanel[Panel.ColourPanel.currentItem].index = CurrentIndex
        
                                    Apperance[Panel.ColourPanel.itemIndex].indextwo = math.floor(CurrentIndex+0.0)
                                    updateApperance(Panel.ColourPanel.itemIndex, true, false)
                                end
                            end)
                        end
        
                        if Panel.PercentagePanel.enable then
                            RageUI.PercentagePanel(Panel.PercentagePanel.index, Panel.PercentagePanel.HeaderText, Panel.PercentagePanel.MinText, Panel.PercentagePanel.MaxText, function(Hovered, Active, Percent)
                                if Panel.PercentagePanel.lastItem == Panel.PercentagePanel.currentItem then
                                    Panel.PercentagePanel.index = Percent
                                else
                                    Panel.PercentagePanel.index = Panel.PercentagePanel[Panel.PercentagePanel.currentItem].index
                                end
                                if Active then
                                    Panel.PercentagePanel[Panel.PercentagePanel.currentItem].index = Percent
        
                                    Apperance[Panel.PercentagePanel.itemIndex].indextwo = math.floor(Percent*10)
                                    updateApperance(Panel.PercentagePanel.itemIndex, false)
                                end
                            end)
                        end
                    end)

                    RageUI.IsVisible(identity2,function()
                        RageUI.Button("Nom", nil, {RightLabel = nom}, true , {
                            onSelected = function()
                                local nameInput = KeyboardInput("nom", 'Indiquez Votre Nom', '', 20)
                                if nameInput ~= nil then
                                    nom = (tostring(nameInput))
                                    RageUI.Popup({message = "Nom ~b~"..nameInput.." ~s~enregistré avec succès"})
                                end
                            end    
                        })
                        RageUI.Button("Prénom", nil, {RightLabel = prenom}, true , {
                            onSelected = function()
                                local prenomInput = KeyboardInput("prenom", 'Indiquez Votre Prénom', '', 20)
                                if prenomInput ~= nil then
                                    prenom = (tostring(prenomInput))
                                    RageUI.Popup({message = "Prénom ~b~"..prenomInput.." ~s~enregistré avec succès"})
                                end
                            end
                        })
                        RageUI.Button("Date de Naissance", nil, {RightLabel = dates}, true , {
                            onSelected = function()
                                local DateInput = KeyboardInput("daten", 'Indiquez Votre Date de Naissance', '', 12)
                                if DateInput ~= nil then
                                    dates = (tostring(DateInput))
                                    RageUI.Popup({message = "Date de Naissance ~b~"..DateInput.." ~s~enregistré avec succès"})
                                end
                            end
                        })
                        RageUI.Button("Taille", nil, {RightLabel = tail}, true , {
                            onSelected = function()
                                local tailleInput = KeyboardInput("tail", 'Indiquez Votre Taille', '', 3)
                                if tailleInput ~= nil then
                                    tail = (tostring(tailleInput))
                                    RageUI.Popup({message = "Taille ~b~"..tailleInput.." ~s~enregistré avec succès"})
                                end
                            end
                        })
                        RageUI.Button("Sexe", nil, {RightLabel = sexe}, true , {
                            onSelected = function()
                              local sexInput = KeyboardInput("sexe", 'Indiquez Votre Sexe (m ou f)', '', 1)
                                if sexInput ~= nil then
                                    sexe = (tostring(sexInput))
                                    if sexe == "m" or sexe == "f" then
                                        RageUI.Popup({message = "Sexe ~b~"..sexInput.." ~s~enregistré avec succès"})
                                        passe = true
                                    else
                                        RageUI.Popup({message = "Demande refusée, veuillez réponde par ~r~m~s~ ou ~r~f~s~."})
                                        passe = false
                                    end
                                end
                            end
                          })
                        RageUI.Button("Valider", nil, {RightLabel = "→→→", Color = {BackgroundColor = RageUI.ItemsColour.Green}}, true , {
                            onSelected = function()
                                local prenomInput = prenom
                                local nameInput = nom
                                local DateInput = dates
                                local tailleInput = tail
                                local sexInput = sexe
                            
                                if not prenomInput then
                                    RageUI.Popup({message = "Vous n'avez pas correctement renseigné la catégorie ~r~Prénom"})
                                elseif not nameInput then
                                    RageUI.Popup({message = "Vous n'avez pas correctement renseigné la catégorie ~r~Nom"})
                                elseif not DateInput then
                                    RageUI.Popup({message = "Vous n'avez pas correctement renseigné la catégorie ~r~Date de naissance"})
                                elseif not tailleInput then
                                    RageUI.Popup({message = "Vous n'avez pas correctement renseigné la catégorie ~r~Taille"})
                                elseif not sexInput then
                                    RageUI.Popup({message = "Vous n'avez pas correctement renseigné la catégorie ~r~Sexe"})
                                else
                                    if passe then
                                        TriggerServerEvent("GB:EventSetInfoToSql", nameInput,prenomInput,DateInput,tailleInput,sexInput)
                                        RageUI.Popup({message = "Identitée Sauvegardée ✅"})
                                        opencrea = false
                                        EndCharCreator()
                                    else
                                        RageUI.Popup({message = "Vous avez mal renseigné votre ~r~Sexe~s~"})
                                    end
                                end
                            end
                        })
                    end)
                Wait(1)
            end
        end)
    end
end