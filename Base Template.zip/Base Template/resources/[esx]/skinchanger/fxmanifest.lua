fx_version 'cerulean'
game 'gta5'

author 'Djinox#4565'
description 'Simple resource de Gestion de Skin'
version '1.0'

client_scripts {
    "skin.lua",
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    "sv_saveskin.lua",
}