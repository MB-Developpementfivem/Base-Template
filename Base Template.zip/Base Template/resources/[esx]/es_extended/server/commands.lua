AddEventHandler('chatMessage', function(source, author, message)
	local _src = source
	if (message):find(Config.CommandPrefix) ~= 1 then
		return
	end

	local commandArgs = ESX.StringSplit(((message):sub((Config.CommandPrefix):len() + 1)), ' ')
	local commandName = (table.remove(commandArgs, 1)):lower()
	local command = ESX.Commands[commandName]

	if command then
		CancelEvent()
		local xPlayer = ESX.GetPlayerFromId(_src)
		if command.group ~= nil then
			if ESX.Groups[xPlayer.getGroup()]:canTarget(ESX.Groups[command.group]) then
				if (command.arguments > -1) and (command.arguments ~= #commandArgs) then
					TriggerEvent("ESX:incorrectAmountOfArguments", _src, command.arguments, #commandArgs)
				else
					command.callback(_src, commandArgs, xPlayer)
				end
			else
				ESX.ChatMessage(_src, 'Permissions Insuffisantes !')
			end
		else
			if (command.arguments > -1) and (command.arguments ~= #commandArgs) then
				TriggerEvent("ESX:incorrectAmountOfArguments", _src, command.arguments, #commandArgs)
			else
				command.callback(_src, commandArgs, xPlayer)
			end
		end
	end
end)

ESX.AddGroupCommand = function(command, group, callback, suggestion, arguments)
	ESX.Commands[command] = {}
	ESX.Commands[command].group = group
	ESX.Commands[command].callback = callback
	ESX.Commands[command].arguments = arguments or -1

	if type(suggestion) == 'table' then
		if type(suggestion.arguments) ~= 'table' then
			suggestion.arguments = {}
		end

		if type(suggestion.help) ~= 'string' then
			suggestion.help = ''
		end
		TriggerClientEvent('chat:addSuggestion', -1, ('/%s'):format(command), suggestion.help, suggestion.arguments)
		table.insert(ESX.CommandsSuggestions, {name = ('%s%s'):format(Config.CommandPrefix, command), help = suggestion.help, arguments = suggestion.arguments})
	end
end

ESX.AddGroupCommand('pos', 'superadmin', function(source, args, user)
	local x, y, z = tonumber(args[1]), tonumber(args[2]), tonumber(args[3])
	
	if x and y and z then
		TriggerClientEvent('esx:teleport', source, vector3(x, y, z))
	else
		ESX.ChatMessage(source, "Invalid coordinates!")
	end
end, {help = "Teleport to coordinates", arguments = {
	{name = "x", help = "X coords"},
	{name = "y", help = "Y coords"},
	{name = "z", help = "Z coords"}
}})

ESX.AddGroupCommand('car', 'superadmin', function(source, args, user)
	TriggerClientEvent('esx:spawnVehicle', source, args[1])
end, {help = 'Spawn un véhicule', arguments = {
	{name = "car", help = 'spawn_car_param'}
}})

ESX.AddGroupCommand('dv', 'admin', function(source, args, user)
	TriggerClientEvent('esx:deleteVehicle', source, args[1])
end, {help = 'Supprimer des véhicules', arguments = {
	{name = 'radius', help = 'Optionel, définit le radius de DV'}
}})

ESX.AddGroupCommand('setjob', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
		if args[2] ~= nil then
			if args[3] ~= nil then
				if ESX.DoesJobExist(args[2], args[3]) then
				    xplayer.setJob(args[2], args[3])
				else
					ESX.ChatMessage(source, "Le job n'existe pas")
				end
			else
				ESX.ChatMessage(source, "Vous devez indiquer le niveau de job")
			end
		else
			ESX.ChatMessage(source, "Vous devez indiquer le job")
		end
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = _U('command_setjob'), arguments = {
	{name = 'playerId', help = _U('commandgeneric_playerid')},
	{name = 'job', help = _U('command_setjob_job')},
	{name = 'grade', help = _U('command_setjob_grade')}
}})

ESX.AddGroupCommand('setjob2', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
		if args[2] ~= nil then
			if args[3] ~= nil then
				if ESX.DoesJob2Exist(args[2], args[3]) then
				    xplayer.setJob2(args[2], args[3])
				else
					ESX.ChatMessage(source, "Le job2 n'existe pas")
				end
			else
				ESX.ChatMessage(source, "Vous devez indiquer le niveau de job2")
			end
		else
			ESX.ChatMessage(source, "Vous devez indiquer le job2")
		end
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = _U('command_setjob2'), arguments = {
	{name = 'playerId', help = _U('commandgeneric_playerid')},
	{name = 'job', help = _U('command_setjob_job2')},
	{name = 'grade', help = _U('command_setjob_grade2')}
}})

---
ESX.AddGroupCommand('giveaccountmoney', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
		if args[2] ~= nil then
			if args[3] ~= nil then
				if xplayer.getAccount(args[2]) then
					local nbr = tonumber(args[3])
					xplayer.addAccountMoney(args[2], nbr)
				else
					ESX.ChatMessage(source, "Type de compte invalide")
				end
			else
				ESX.ChatMessage(source, "Vous devez indiquer la somme à give")
			end
		else
			ESX.ChatMessage(source, "Vous devez indiquer le type de compte")
		end
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = _U('command_giveaccountmoney'), arguments = {
	{name = 'playerId', help = _U('commandgeneric_playerid')},
	{name = 'account', help = _U('command_giveaccountmoney_account')},
	{name = 'amount', help = _U('command_giveaccountmoney_amount')}
}})

ESX.AddGroupCommand('giveitem', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
		if args[2] ~= nil then
			if args[3] ~= nil then
	            xplayer.addInventoryItem(args[2], args[3])
			else
				ESX.ChatMessage(source, "Vous devez indiquer le nombre d'item")
			end
		else
			ESX.ChatMessage(source, "Vous devez indiquer le type d'item")
		end
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = _U('command_giveitem'), arguments = {
	{name = 'playerId', help = _U('commandgeneric_playerid')},
	{name = 'item', help = _U('command_giveitem_item')},
	{name = 'count', help = _U('command_giveitem_count')}
}})


ESX.AddGroupCommand('giveweapon', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
		if args[2] ~= nil then
			if args[3] ~= nil then
				local nbra = tonumber(args[3])
	            xplayer.addWeapon(args[2], nbra)
			else
				ESX.ChatMessage(source, "Vous devez indiquer le nombre de munitions")
			end
		else
			ESX.ChatMessage(source, "Vous devez indiquer le type d'arme")
		end
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = _U('command_giveweapon'), arguments = {
	{name = 'playerId', help = _U('commandgeneric_playerid')},
	{name = 'weapon', help = _U('command_giveweapon_weapon')},
	{name = 'ammo', help = _U('command_giveweapon_ammo')}
}})

ESX.AddGroupCommand('giveweaponcomponent', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
		if xplayer.hasWeapon(args[2]) then
			if args[2] ~= nil then
				if args[3] ~= nil then
					local component = ESX.GetWeaponComponent(args[2], args[3])
					if component then
						if xplayer.hasWeaponComponent(args[2], args[3]) then
							ESX.ChatMessage("Le joueur a déjà cet accessoire")
						else
							xplayer.addWeaponComponent(args[2], args[3])
						end
					else
						ESX.ChatMessage(source, "Accessoire Invalide")
					end
				else
					ESX.ChatMessage(source, "Vous devez indiquer le type d'accessoire")
				end
			else
				ESX.ChatMessage(source, "Vous devez indiquer le type d'arme")
			end
		else
			ESX.ChatMessage(source, "Le joueur n\'a pas cette arme")
		end
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = _U('command_giveweapon'), arguments = {
	{name = 'playerId', help = _U('commandgeneric_playerid')},
	{name = 'weaponName', help = _U('command_giveweapon_weapon')},
	{name = 'componentName', help = _U('command_giveweaponcomponent_component')}
}})


ESX.AddGroupCommand('clearweapon', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
		for i=#xplayer.loadout, 1, -1 do
			xplayer.removeWeapon(xplayer.loadout[i].name)
		end
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = 'Sauvegarder un joueur', arguments = {
	{name = "Id", help = 'Id du joueur'}
}})

ESX.AddGroupCommand('clear', 'user', function(xPlayer, args, user)
	xPlayer.triggerEvent('chat:clear')
end, {help = 'Vider le chat'})

ESX.AddGroupCommand('chatclear', 'admin', function(source, args, user)
	TriggerClientEvent('chat:clear', -1)
end, {help = 'Vider le chat pour tout le monde'})


ESX.AddGroupCommand('save', 'superadmin', function(source, args, user)
	local xplayer = ESX.GetPlayerFromId(args[1])
	if xplayer ~= nil then
	    ESX.SavePlayer(xplayer)
	else
		ESX.ChatMessage(source, "Id n'existe pas")
	end
end, {help = 'Sauvegarder un joueur', arguments = {
	{name = "Id", help = 'Id du joueur'}
}})

ESX.AddGroupCommand('saveall', 'superadmin', function(source, args, user)
	ESX.SavePlayers()
end, {help = 'Sauvegarder tous les joueurs'})