ESX.StartPayCheck = function()
	function payCheck()
		local xPlayers = ESX.GetPlayers()
		for i=1, #xPlayers, 1 do
			local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
			local job     = xPlayer.job.grade_name
			local job2     = xPlayer.job2.grade_name
			local salary  = xPlayer.job.grade_salary
			local salary2  = xPlayer.job2.grade_salary

			if Config.EnableSocietyPayouts then
				----faire payement
			else
				if salary > 0 then
					if job == 'unemployed' then -- unemployed
						xPlayer.addAccountMoney('bank', salary)
						TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous avez reçu votre salaire de ~g~"..salary.." $~s~")
					else
						xPlayer.addAccountMoney('bank', salary)
						TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous avez reçu votre salaire de ~g~"..salary.." $~s~")
					end
				end
			end

            if Config.PaycheckJob2 then
                if salary2 > 0 then
                    if job2 == 'unemployed2' then -- unemployed
                        xPlayer.addAccountMoney('bank', salary2)
                        TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous avez reçu votre salaire de ~g~"..salary2.." $~s~")
                    else
                        xPlayer.addAccountMoney('bank', salary2)
                        TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous avez reçu votre salaire de ~g~"..salary2.." $~s~")
                    end
                end
            end
		end
		SetTimeout(Config.PaycheckInterval, payCheck)
	end
	SetTimeout(Config.PaycheckInterval, payCheck)
end
