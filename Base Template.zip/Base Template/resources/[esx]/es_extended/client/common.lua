AddEventHandler('esx:getSharedObject', function(cb)
	cb(ESX)
end)

function getExtented()
	return ESX
end
