Config = {}
Config.Locale = 'fr'

Config.DefaultGroup = 'user'
Config.CommandPrefix = '/'

Config.Accounts = {
	bank = _U('account_bank'),
	black_money = _U('account_black_money'),
	money = _U('account_money')
}

Config.StartingAccountMoney = {
	money = 10000,
	bank = 10000,
	black_money = 10000
}

Config.EnableSocietyPayouts 	= false       -- active systme facture grace au entreprise si false alors salaire vient du server
Config.MaxWeight            	= 24         -- max place inventaire
Config.PaycheckInterval     	= 7 * 60000 -- facture interval en millisecondes --7 * 60000
Config.PaycheckJob2         	= false       -- salaire job2
